package com.example.withtalk2.model;

/**
 * Created by myeongsic on 2017. 8. 14..
 */

public class UserModel {
    public String userName;
    public String profileImageUrl;
    public String uid;
    public String pushToken;
    public String comment;

}
